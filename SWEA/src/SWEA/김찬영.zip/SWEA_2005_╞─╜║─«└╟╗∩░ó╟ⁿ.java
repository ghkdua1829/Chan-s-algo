package SWEA;

import java.util.Arrays;
import java.util.Scanner;

public class SWEA_2005_파스칼의삼각형 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int tc = 1; tc <= T; tc++) {
			int triangleSize = sc.nextInt();
			int[][] triangle = new int[triangleSize][triangleSize];
			for (int[] row : triangle) {
				Arrays.fill(row, 1); // 1로 가득 채우기
			}
			for (int r = 0; r < triangleSize; r++) {
				for (int c = r + 1; c < triangleSize; c++) {
					triangle[r][c] = 0; // 0으로 채우기 (반 윗부분)
				}
			}
			for (int i = 1; i < triangleSize; i++) {
				for (int j = 1; j < triangleSize; j++) {
					triangle[i][j]=triangle[i-1][j-1]+triangle[i-1][j];
				}
			}
			
			System.out.println("#" + tc);

			for (int i = 0; i < triangleSize; i++) {
				for (int j = 0; j < triangleSize; j++) {
					if(triangle[i][j]!=0) {
						System.out.print(triangle[i][j]+" ");
					}
				}
				System.out.println();
			}

		}
	}

}
