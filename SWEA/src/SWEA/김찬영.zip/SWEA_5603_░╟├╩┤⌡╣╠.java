package SWEA;

import java.util.Scanner;

public class SWEA_5603_건초더미 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			int hayCount = sc.nextInt();
			int[] arr = new int[hayCount];
			int sum = 0;
			for (int j = 0; j < hayCount; j++) {
				arr[j] = sc.nextInt();
				sum += arr[j];
			}
			int avg = sum / hayCount;
			int result = 0;
			for (int j = 0; j < hayCount; j++) {
				if (arr[j] > avg) {
					result += arr[j] - avg;
				}
			}
			System.out.println("#" + (i + 1) + " " + result);
		}
	}

}
